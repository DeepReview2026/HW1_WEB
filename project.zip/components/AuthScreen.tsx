import { useState } from 'react';
import { User } from '../App';
import { BookOpen, Users, Brain } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (user: User) => void;
}

export function AuthScreen({ onLogin }: AuthScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'student' | 'instructor'>('student');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock login - create user object
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: name || email.split('@')[0],
      email,
      role,
    };
    
    onLogin(user);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full grid md:grid-cols-2 gap-8">
        {/* Left side - Hero */}
        <div className="hidden md:flex flex-col justify-center space-y-6 text-gray-800">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 bg-white/50 backdrop-blur-sm px-4 py-2 rounded-full">
              <Brain className="w-5 h-5 text-indigo-600" />
              <span>מערכת AI לניתוח מאמרים</span>
            </div>
            <h1 className="text-5xl">
              למידה חכמה של
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">
                מאמרים אקדמיים
              </span>
            </h1>
            <p className="text-xl text-gray-600">
              עבדו בצורה חכמה עם מאמרים מדעיים, שאלו שאלות, קבלו תקצירים והשוו מחקרים
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3 bg-white/50 backdrop-blur-sm p-4 rounded-xl">
              <BookOpen className="w-6 h-6 text-indigo-600 mt-1" />
              <div>
                <h3>ניתוח אוטומטי</h3>
                <p className="text-gray-600">העלו PDF וקבלו ניתוח מלא של המאמר</p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-white/50 backdrop-blur-sm p-4 rounded-xl">
              <Brain className="w-6 h-6 text-purple-600 mt-1" />
              <div>
                <h3>בוט סוקרטי</h3>
                <p className="text-gray-600">למידה באמצעות שאלות מנחות וחשיבה ביקורתית</p>
              </div>
            </div>
            <div className="flex items-start gap-3 bg-white/50 backdrop-blur-sm p-4 rounded-xl">
              <Users className="w-6 h-6 text-pink-600 mt-1" />
              <div>
                <h3>פאנל מרצים</h3>
                <p className="text-gray-600">מעקב אחר התקדמות ואיכות הלמידה</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Auth Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="mb-8">
            <h2 className="text-3xl mb-2">
              {isLogin ? 'התחברות' : 'הרשמה'}
            </h2>
            <p className="text-gray-600">
              {isLogin
                ? 'היכנסו לחשבון שלכם כדי להמשיך'
                : 'צרו חשבון חדש והתחילו לעבוד עם מאמרים'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div>
                <label htmlFor="name" className="block mb-2 text-gray-700">
                  שם מלא
                </label>
                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                  placeholder="הכניסו את שמכם"
                />
              </div>
            )}

            <div>
              <label htmlFor="email" className="block mb-2 text-gray-700">
                אימייל
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="name@example.com"
              />
            </div>

            <div>
              <label htmlFor="password" className="block mb-2 text-gray-700">
                סיסמה
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                placeholder="••••••••"
              />
            </div>

            {!isLogin && (
              <div>
                <label className="block mb-2 text-gray-700">תפקיד</label>
                <div className="flex gap-4">
                  <label className="flex-1 relative">
                    <input
                      type="radio"
                      value="student"
                      checked={role === 'student'}
                      onChange={(e) => setRole(e.target.value as 'student')}
                      className="peer sr-only"
                    />
                    <div className="px-4 py-3 border-2 border-gray-300 rounded-lg cursor-pointer transition peer-checked:border-indigo-600 peer-checked:bg-indigo-50 text-center">
                      סטודנט
                    </div>
                  </label>
                  <label className="flex-1 relative">
                    <input
                      type="radio"
                      value="instructor"
                      checked={role === 'instructor'}
                      onChange={(e) => setRole(e.target.value as 'instructor')}
                      className="peer sr-only"
                    />
                    <div className="px-4 py-3 border-2 border-gray-300 rounded-lg cursor-pointer transition peer-checked:border-indigo-600 peer-checked:bg-indigo-50 text-center">
                      מרצה
                    </div>
                  </label>
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition"
            >
              {isLogin ? 'התחברות' : 'הרשמה'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-indigo-600 hover:text-indigo-700 transition"
            >
              {isLogin ? 'אין לך חשבון? הירשם כאן' : 'יש לך חשבון? התחבר כאן'}
            </button>
          </div>

          {/* Quick login buttons for demo */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-gray-600 text-center mb-3">כניסה מהירה לדמו:</p>
            <div className="flex gap-2">
              <button
                onClick={() => onLogin({
                  id: 'demo-student',
                  name: 'דמו סטודנט',
                  email: 'student@demo.com',
                  role: 'student',
                })}
                className="flex-1 px-4 py-2 border-2 border-indigo-300 text-indigo-700 rounded-lg hover:bg-indigo-50 transition"
              >
                סטודנט
              </button>
              <button
                onClick={() => onLogin({
                  id: 'demo-instructor',
                  name: 'דמו מרצה',
                  email: 'instructor@demo.com',
                  role: 'instructor',
                })}
                className="flex-1 px-4 py-2 border-2 border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50 transition"
              >
                מרצה
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
