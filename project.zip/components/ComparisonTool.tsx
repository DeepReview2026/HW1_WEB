import { useState } from 'react';
import { Paper } from '../App';
import { GitCompare, CheckCircle2 } from 'lucide-react';

interface ComparisonToolProps {
  papers: Paper[];
}

export function ComparisonTool({ papers }: ComparisonToolProps) {
  const [paper1, setPaper1] = useState<Paper | null>(null);
  const [paper2, setPaper2] = useState<Paper | null>(null);

  const comparisonCategories = [
    { key: 'title', label: 'כותרת' },
    { key: 'year', label: 'שנת פרסום' },
    { key: 'authors', label: 'מחברים' },
    { key: 'researchQuestion', label: 'שאלת מחקר' },
    { key: 'methodology', label: 'מתודולוגיה' },
    { key: 'sampleSize', label: 'גודל מדגם' },
    { key: 'findings', label: 'ממצאים עיקריים' },
    { key: 'limitations', label: 'מגבלות' },
  ];

  const getComparisonData = (paper: Paper, key: string): string => {
    switch (key) {
      case 'title':
        return paper.title;
      case 'year':
        return paper.year.toString();
      case 'authors':
        return paper.authors.join(', ');
      case 'researchQuestion':
        if (paper.title.includes('Machine Learning')) {
          return 'האם ML יכול להשיג ביצועים טובים יותר ממומחים אנושיים באבחון רפואי?';
        }
        if (paper.title.includes('Social Media')) {
          return 'מה הקשר בין שימוש ברשתות חברתיות לביצועים אקדמיים?';
        }
        if (paper.title.includes('Climate')) {
          return 'כיצד שינויי אקלים משפיעים על המגוון הביולוגי הים תיכוני?';
        }
        return 'לא זוהתה';
      case 'methodology':
        if (paper.title.includes('Machine Learning')) {
          return 'CNN מבוסס ResNet-50, 50,000 סריקות CT';
        }
        if (paper.title.includes('Social Media')) {
          return 'מחקר אורכי, 1,200 סטודנטים, סקרים שבועיים';
        }
        if (paper.title.includes('Climate')) {
          return 'סקרי שטח ב-150 אתרים, 12 מדינות';
        }
        return 'לא צוין';
      case 'sampleSize':
        if (paper.title.includes('Machine Learning')) {
          return '50,000 סריקות CT';
        }
        if (paper.title.includes('Social Media')) {
          return '1,200 סטודנטים';
        }
        if (paper.title.includes('Climate')) {
          return '150 אתרים מחקר';
        }
        return 'לא צוין';
      case 'findings':
        if (paper.title.includes('Machine Learning')) {
          return 'דיוק 94%, שיפור של 7% על שיטות מסורתיות';
        }
        if (paper.title.includes('Social Media')) {
          return 'מתאם שלילי -0.43 בין זמן שימוש ל-GPA';
        }
        if (paper.title.includes('Climate')) {
          return 'ירידה של 23% במינים אנדמיים';
        }
        return 'לא צוינו';
      case 'limitations':
        if (paper.title.includes('Machine Learning')) {
          return 'מוגבל ל-CT בלבד, נתונים עירוניים בעיקר';
        }
        if (paper.title.includes('Social Media')) {
          return 'דיווח עצמי, משתנים מתערבים לא מלאים';
        }
        if (paper.title.includes('Climate')) {
          return 'מערכות יבשתיות בלבד, מגבלות תקציב';
        }
        return 'לא צוינו';
      default:
        return '';
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl mb-2">השוואת מאמרים</h2>
        <p className="text-gray-600">
          בחר שני מאמרים להשוואה מפורטת
        </p>
      </div>

      {/* Paper Selection */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Paper 1 Selection */}
        <div>
          <label className="block mb-2 text-gray-700">מאמר ראשון</label>
          <select
            value={paper1?.id || ''}
            onChange={(e) => {
              const selected = papers.find((p) => p.id === e.target.value);
              setPaper1(selected || null);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
          >
            <option value="">בחר מאמר...</option>
            {papers.map((paper) => (
              <option key={paper.id} value={paper.id}>
                {paper.title}
              </option>
            ))}
          </select>
          {paper1 && (
            <div className="mt-4 p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
              <div className="flex items-center gap-2 text-indigo-700 mb-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>נבחר</span>
              </div>
              <p className="text-sm text-gray-700">{paper1.title}</p>
              <p className="text-sm text-gray-600 mt-1">
                {paper1.authors[0]} · {paper1.year}
              </p>
            </div>
          )}
        </div>

        {/* Paper 2 Selection */}
        <div>
          <label className="block mb-2 text-gray-700">מאמר שני</label>
          <select
            value={paper2?.id || ''}
            onChange={(e) => {
              const selected = papers.find((p) => p.id === e.target.value);
              setPaper2(selected || null);
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none"
          >
            <option value="">בחר מאמר...</option>
            {papers.map((paper) => (
              <option key={paper.id} value={paper.id} disabled={paper.id === paper1?.id}>
                {paper.title}
              </option>
            ))}
          </select>
          {paper2 && (
            <div className="mt-4 p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="flex items-center gap-2 text-purple-700 mb-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>נבחר</span>
              </div>
              <p className="text-sm text-gray-700">{paper2.title}</p>
              <p className="text-sm text-gray-600 mt-1">
                {paper2.authors[0]} · {paper2.year}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Comparison Table */}
      {paper1 && paper2 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-right border-b border-gray-200">
                    קטגוריה
                  </th>
                  <th className="px-6 py-4 text-right border-b border-indigo-200 bg-indigo-50">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-indigo-600 rounded-full" />
                      <span>מאמר ראשון</span>
                    </div>
                  </th>
                  <th className="px-6 py-4 text-right border-b border-purple-200 bg-purple-50">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-purple-600 rounded-full" />
                      <span>מאמר שני</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisonCategories.map((category, index) => (
                  <tr
                    key={category.key}
                    className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}
                  >
                    <td className="px-6 py-4 border-b border-gray-200">
                      {category.label}
                    </td>
                    <td className="px-6 py-4 border-b border-gray-200 border-r border-r-indigo-100">
                      <span className="text-gray-700">
                        {getComparisonData(paper1, category.key)}
                      </span>
                    </td>
                    <td className="px-6 py-4 border-b border-gray-200 border-r border-r-purple-100">
                      <span className="text-gray-700">
                        {getComparisonData(paper2, category.key)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Export Button */}
          <div className="p-6 bg-gray-50 border-t border-gray-200">
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition">
              ייצוא השוואה ל-PDF
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
            <GitCompare className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl mb-2">בחר שני מאמרים להשוואה</h3>
          <p className="text-gray-600">
            לאחר הבחירה תוכל לראות טבלת השוואה מפורטת
          </p>
        </div>
      )}
    </div>
  );
}
