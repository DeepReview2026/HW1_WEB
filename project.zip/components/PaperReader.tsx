import { Paper } from '../App';
import { X, BookOpen, Calendar, Users, Tag, Maximize2, Minimize2 } from 'lucide-react';
import { useState } from 'react';

interface PaperReaderProps {
  paper: Paper;
  onClose: () => void;
}

export function PaperReader({ paper, onClose }: PaperReaderProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div 
        className={`bg-white rounded-xl shadow-2xl flex flex-col transition-all ${
          isFullscreen ? 'w-full h-full' : 'max-w-4xl w-full h-[90vh]'
        }`}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-gray-200 flex-shrink-0">
          <div className="flex-1 ml-4">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <span className="text-sm text-indigo-600">קריאת מאמר</span>
            </div>
            <h2 className="text-2xl mb-3">{paper.title}</h2>
            
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span>{paper.authors.join(', ')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{paper.year}</span>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
              {paper.keywords.map((keyword, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-1 px-2 py-1 bg-indigo-100 text-indigo-700 rounded text-xs"
                >
                  <Tag className="w-3 h-3" />
                  {keyword}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
              title={isFullscreen ? 'צמצם' : 'הרחב למסך מלא'}
            >
              {isFullscreen ? (
                <Minimize2 className="w-5 h-5 text-gray-600" />
              ) : (
                <Maximize2 className="w-5 h-5 text-gray-600" />
              )}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Abstract */}
            <section className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
              <h3 className="text-lg mb-3 text-indigo-900">תקציר (Abstract)</h3>
              <p className="text-gray-800 leading-relaxed">{paper.abstract}</p>
            </section>

            {/* Full Text */}
            <section className="prose prose-gray max-w-none">
              <div className="whitespace-pre-line text-gray-800 leading-relaxed">
                {paper.fullText}
              </div>
            </section>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 bg-gray-50 flex items-center justify-between flex-shrink-0">
          <div className="text-sm text-gray-600">
            הועלה ב-{new Date(paper.uploadDate).toLocaleDateString('he-IL')}
          </div>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
          >
            סגור
          </button>
        </div>
      </div>
    </div>
  );
}
