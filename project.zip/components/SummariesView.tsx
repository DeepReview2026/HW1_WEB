import { Paper } from '../App';
import { FileText, Download, Sparkles } from 'lucide-react';

interface SummariesViewProps {
  papers: Paper[];
}

export function SummariesView({ papers }: SummariesViewProps) {
  const generateSummary = (paper: Paper) => {
    if (paper.title.includes('Machine Learning')) {
      return {
        purpose: 'בדיקת יכולת מודלי למידת מכונה לזהות גידולים ממאירים מסריקות CT ברמה שווה או טובה יותר ממומחים אנושיים',
        method: 'רשת נוירונים קונבולוציונית (CNN) מבוססת ResNet-50 שאומנה על 50,000 סריקות CT מתוייגות',
        findings: 'דיוק של 94%, רגישות 92%, ספציפיות 96% - שיפור של 7% על שיטות מסורתיות',
        conclusions: 'ML מבטיחה באבחון רפואי אך צריכה לשמש ככלי משלים למומחיות אנושית',
        limitations: 'מוגבל לסריקות CT, נתונים בעיקר מבתי חולים עירוניים',
      };
    }
    if (paper.title.includes('Social Media')) {
      return {
        purpose: 'הבנת הקשר בין דפוסי שימוש ברשתות חברתיות לביצועים אקדמיים של סטודנטים',
        method: 'מחקר אורכי במשך שנה עם 1,200 סטודנטים משלוש אוניברסיטאות, סקרים שבועיים ורישומים אקדמיים',
        findings: 'מתאם שלילי בינוני (-0.43) בין זמן שימוש יומי ל-GPA. סטודנטים עם 3+ שעות: GPA 2.8, פחות משעה: GPA 3.4. שימוש חינוכי הראה מתאם חיובי',
        conclusions: 'שימוש מוגזם קשור לביצועים נמוכים, אך שימוש מודע וחינוכי יכול להיות מועיל',
        limitations: 'דיווח עצמי עלול להיות מוטה, לא כל המשתנים המתערבים נשלטו',
      };
    }
    if (paper.title.includes('Climate')) {
      return {
        purpose: 'בחינת השפעת שינויי האקלים על המגוון הביולוגי באזור הים התיכון והערכת תחזיות עתידיות',
        method: 'סקרי שטח ב-150 אתרים ב-12 מדינות, השוואה לנתונים היסטוריים מ-2000-2004',
        findings: 'ירידה של 23% במינים אנדמיים, 37% במינים רגישים לטמפרטורה. תחזית: 30-40% נוספים בסכנת הכחדה עד 2050',
        conclusions: 'נדרשת פעולת שימור דחופה - הקמת אזורי שמורה נוספים ותוכניות הגירה מסייעת',
        limitations: 'התמקדות במערכות יבשתיות, ללא ניתוח גיוון גנטי בשל מגבלות תקציב',
      };
    }
    return {
      purpose: paper.abstract,
      method: 'לא זוהתה',
      findings: 'לא זוהו',
      conclusions: 'לא זוהו',
      limitations: 'לא זוהו',
    };
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl mb-2">תקצירים אוטומטיים</h2>
        <p className="text-gray-600">
          תקצירים מובנים של כל המאמרים בספרייה
        </p>
      </div>

      <div className="space-y-6">
        {papers.map((paper) => {
          const summary = generateSummary(paper);
          
          return (
            <div
              key={paper.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 border-b border-gray-200">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="mb-2">{paper.title}</h3>
                    <p className="text-gray-600">
                      {paper.authors.join(', ')} · {paper.year}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-white rounded-full">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    <span className="text-sm text-gray-700">תקציר AI</span>
                  </div>
                </div>
              </div>

              {/* Summary Content */}
              <div className="p-6 space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-indigo-600 rounded-full" />
                    <h4 className="text-gray-900">מטרת המחקר</h4>
                  </div>
                  <p className="text-gray-700 pr-4">{summary.purpose}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-purple-600 rounded-full" />
                    <h4 className="text-gray-900">מתודולוגיה</h4>
                  </div>
                  <p className="text-gray-700 pr-4">{summary.method}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-pink-600 rounded-full" />
                    <h4 className="text-gray-900">ממצאים עיקריים</h4>
                  </div>
                  <p className="text-gray-700 pr-4">{summary.findings}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full" />
                    <h4 className="text-gray-900">מסקנות</h4>
                  </div>
                  <p className="text-gray-700 pr-4">{summary.conclusions}</p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 bg-orange-600 rounded-full" />
                    <h4 className="text-gray-900">מגבלות</h4>
                  </div>
                  <p className="text-gray-700 pr-4">{summary.limitations}</p>
                </div>
              </div>

              {/* Footer */}
              <div className="bg-gray-50 p-4 border-t border-gray-200 flex items-center justify-between">
                <div className="flex gap-2">
                  {paper.keywords.slice(0, 4).map((keyword, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-white border border-gray-200 rounded-full text-sm text-gray-700"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
                <button className="flex items-center gap-2 px-4 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition">
                  <Download className="w-4 h-4" />
                  ייצוא
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {papers.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl mb-2">אין מאמרים</h3>
          <p className="text-gray-600">
            העלה מאמרים כדי לראות תקצירים אוטומטיים
          </p>
        </div>
      )}

      {/* Bulk Export */}
      {papers.length > 0 && (
        <div className="mt-8 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="mb-1">ייצוא כל התקצירים</h3>
              <p className="text-gray-600">
                ייצא את כל התקצירים למסמך אחד מסודר
              </p>
            </div>
            <button className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition">
              ייצוא הכל ל-PDF
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
