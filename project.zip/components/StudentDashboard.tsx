import { useState } from 'react';
import { User, Paper } from '../App';
import { LogOut, Upload, BookOpen, MessageSquare, GitCompare, FileText, Brain } from 'lucide-react';
import { PapersLibrary } from './PapersLibrary';
import { ChatInterface } from './ChatInterface';
import { ComparisonTool } from './ComparisonTool';
import { SummariesView } from './SummariesView';
import { UploadPaper } from './UploadPaper';
import { mockPapers } from '../data/mockPapers';

interface StudentDashboardProps {
  user: User;
  onLogout: () => void;
}

type Tab = 'library' | 'upload' | 'chat' | 'compare' | 'summaries';

export function StudentDashboard({ user, onLogout }: StudentDashboardProps) {
  const [activeTab, setActiveTab] = useState<Tab>('library');
  const [papers, setPapers] = useState<Paper[]>(mockPapers);
  const [selectedPaper, setSelectedPaper] = useState<Paper | null>(null);
  const [socraticMode, setSocraticMode] = useState(false);

  const handlePaperUpload = (newPaper: Paper) => {
    setPapers([...papers, newPaper]);
    setActiveTab('library');
  };

  const handleSelectPaper = (paper: Paper) => {
    setSelectedPaper(paper);
    setActiveTab('chat');
  };

  const tabs = [
    { id: 'library' as Tab, label: 'הספרייה שלי', icon: BookOpen },
    { id: 'upload' as Tab, label: 'העלאת מאמר', icon: Upload },
    { id: 'chat' as Tab, label: 'שיחה עם הבוט', icon: MessageSquare },
    { id: 'compare' as Tab, label: 'השוואת מאמרים', icon: GitCompare },
    { id: 'summaries' as Tab, label: 'תקצירים', icon: FileText },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">מערכת ניתוח מאמרים</h1>
                <p className="text-gray-600">שלום, {user.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={socraticMode}
                  onChange={(e) => setSocraticMode(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                />
                <span className="text-gray-700">מצב סוקרטי</span>
                <Brain className="w-4 h-4 text-purple-600" />
              </label>
              <button
                onClick={onLogout}
                className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
              >
                <LogOut className="w-4 h-4" />
                יציאה
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition ${
                    activeTab === tab.id
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {activeTab === 'library' && (
            <PapersLibrary papers={papers} onSelectPaper={handleSelectPaper} />
          )}
          {activeTab === 'upload' && (
            <UploadPaper onUpload={handlePaperUpload} />
          )}
          {activeTab === 'chat' && (
            <ChatInterface 
              selectedPaper={selectedPaper} 
              socraticMode={socraticMode}
              onSelectPaper={() => setActiveTab('library')}
            />
          )}
          {activeTab === 'compare' && (
            <ComparisonTool papers={papers} />
          )}
          {activeTab === 'summaries' && (
            <SummariesView papers={papers} />
          )}
        </div>
      </main>
    </div>
  );
}
