import { useState } from 'react';
import { User } from '../App';
import { LogOut, Users, TrendingUp, Brain, BookOpen, MessageSquare, Award } from 'lucide-react';

interface InstructorDashboardProps {
  user: User;
  onLogout: () => void;
}

interface StudentData {
  id: string;
  name: string;
  email: string;
  papersCount: number;
  conversationsCount: number;
  avgUnderstandingScore: number;
  criticalThinkingScore: number;
  lastActive: string;
  progress: {
    understanding: number;
    analysis: number;
    critique: number;
    synthesis: number;
  };
}

const mockStudents: StudentData[] = [
  {
    id: '1',
    name: 'שרה כהן',
    email: 'sarah@example.com',
    papersCount: 5,
    conversationsCount: 12,
    avgUnderstandingScore: 87,
    criticalThinkingScore: 82,
    lastActive: '2024-11-20',
    progress: {
      understanding: 90,
      analysis: 85,
      critique: 78,
      synthesis: 88,
    },
  },
  {
    id: '2',
    name: 'דוד לוי',
    email: 'david@example.com',
    papersCount: 3,
    conversationsCount: 8,
    avgUnderstandingScore: 75,
    criticalThinkingScore: 70,
    lastActive: '2024-11-21',
    progress: {
      understanding: 80,
      analysis: 72,
      critique: 65,
      synthesis: 73,
    },
  },
  {
    id: '3',
    name: 'מיכל אברהם',
    email: 'michal@example.com',
    papersCount: 7,
    conversationsCount: 18,
    avgUnderstandingScore: 92,
    criticalThinkingScore: 89,
    lastActive: '2024-11-22',
    progress: {
      understanding: 95,
      analysis: 91,
      critique: 87,
      synthesis: 90,
    },
  },
  {
    id: '4',
    name: 'יוסי מזרחי',
    email: 'yossi@example.com',
    papersCount: 2,
    conversationsCount: 5,
    avgUnderstandingScore: 68,
    criticalThinkingScore: 64,
    lastActive: '2024-11-18',
    progress: {
      understanding: 70,
      analysis: 68,
      critique: 60,
      synthesis: 65,
    },
  },
];

export function InstructorDashboard({ user, onLogout }: InstructorDashboardProps) {
  const [selectedStudent, setSelectedStudent] = useState<StudentData | null>(null);

  const averageScore = Math.round(
    mockStudents.reduce((sum, s) => sum + s.avgUnderstandingScore, 0) / mockStudents.length
  );

  const totalPapers = mockStudents.reduce((sum, s) => sum + s.papersCount, 0);
  const totalConversations = mockStudents.reduce((sum, s) => sum + s.conversationsCount, 0);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">פאנל מרצה</h1>
                <p className="text-gray-600">שלום, {user.name}</p>
              </div>
            </div>
            <button
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
            >
              <LogOut className="w-4 h-4" />
              יציאה
            </button>
          </div>
        </div>
      </header>

      {/* Stats Overview */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-8 h-8 text-purple-600" />
                <span className="text-3xl">{mockStudents.length}</span>
              </div>
              <p className="text-gray-600">סטודנטים פעילים</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <BookOpen className="w-8 h-8 text-indigo-600" />
                <span className="text-3xl">{totalPapers}</span>
              </div>
              <p className="text-gray-600">מאמרים הועלו</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <MessageSquare className="w-8 h-8 text-blue-600" />
                <span className="text-3xl">{totalConversations}</span>
              </div>
              <p className="text-gray-600">שיחות עם הבוט</p>
            </div>
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-8 h-8 text-green-600" />
                <span className="text-3xl">{averageScore}%</span>
              </div>
              <p className="text-gray-600">ממוצע הבנה</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Students List */}
            <div className="lg:col-span-2">
              <div className="mb-6">
                <h2 className="text-2xl mb-2">רשימת סטודנטים</h2>
                <p className="text-gray-600">
                  לחץ על סטודנט לצפייה בפירוט
                </p>
              </div>

              <div className="space-y-4">
                {mockStudents.map((student) => (
                  <div
                    key={student.id}
                    onClick={() => setSelectedStudent(student)}
                    className={`bg-white rounded-xl shadow-sm border-2 p-6 cursor-pointer transition ${
                      selectedStudent?.id === student.id
                        ? 'border-purple-600 shadow-md'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white">
                          {student.name.charAt(0)}
                        </div>
                        <div>
                          <h3 className="mb-1">{student.name}</h3>
                          <p className="text-gray-600 text-sm">{student.email}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <div className="flex items-center gap-2 mb-1">
                          <Award className="w-4 h-4 text-purple-600" />
                          <span className="text-purple-600">{student.avgUnderstandingScore}%</span>
                        </div>
                        <p className="text-gray-600 text-sm">
                          פעיל {new Date(student.lastActive).toLocaleDateString('he-IL')}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div className="bg-indigo-50 rounded-lg p-3 text-center">
                        <div className="text-2xl text-indigo-600 mb-1">
                          {student.papersCount}
                        </div>
                        <div className="text-gray-600 text-sm">מאמרים</div>
                      </div>
                      <div className="bg-blue-50 rounded-lg p-3 text-center">
                        <div className="text-2xl text-blue-600 mb-1">
                          {student.conversationsCount}
                        </div>
                        <div className="text-gray-600 text-sm">שיחות</div>
                      </div>
                      <div className="bg-purple-50 rounded-lg p-3 text-center">
                        <div className="text-2xl text-purple-600 mb-1">
                          {student.criticalThinkingScore}%
                        </div>
                        <div className="text-gray-600 text-sm">חשיבה ביקורתית</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Student Details */}
            <div className="lg:col-span-1">
              {selectedStudent ? (
                <div className="sticky top-4">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="mb-6">
                      <h3 className="mb-2">פירוט התקדמות</h3>
                      <p className="text-gray-600">{selectedStudent.name}</p>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">הבנת תוכן</span>
                          <span className="text-indigo-600">
                            {selectedStudent.progress.understanding}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-indigo-500 to-indigo-600 h-2 rounded-full transition-all"
                            style={{ width: `${selectedStudent.progress.understanding}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">יכולת ניתוח</span>
                          <span className="text-purple-600">
                            {selectedStudent.progress.analysis}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-purple-500 to-purple-600 h-2 rounded-full transition-all"
                            style={{ width: `${selectedStudent.progress.analysis}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">חשיבה ביקורתית</span>
                          <span className="text-pink-600">
                            {selectedStudent.progress.critique}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-pink-500 to-pink-600 h-2 rounded-full transition-all"
                            style={{ width: `${selectedStudent.progress.critique}%` }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-gray-700">סינתזה</span>
                          <span className="text-blue-600">
                            {selectedStudent.progress.synthesis}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${selectedStudent.progress.synthesis}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 pt-6 border-t border-gray-200">
                      <h4 className="mb-3">ניתוח ביצועים</h4>
                      <div className="space-y-2 text-sm">
                        {selectedStudent.avgUnderstandingScore >= 85 ? (
                          <>
                            <p className="text-green-700 bg-green-50 p-3 rounded-lg">
                              ✓ הבנה מצוינת של חומר המחקר
                            </p>
                            <p className="text-green-700 bg-green-50 p-3 rounded-lg">
                              ✓ פעילות גבוהה ועקבית
                            </p>
                          </>
                        ) : selectedStudent.avgUnderstandingScore >= 75 ? (
                          <>
                            <p className="text-blue-700 bg-blue-50 p-3 rounded-lg">
                              → הבנה טובה, מומלץ להמשיך
                            </p>
                            <p className="text-blue-700 bg-blue-50 p-3 rounded-lg">
                              → עבודה עקבית על המאמרים
                            </p>
                          </>
                        ) : (
                          <>
                            <p className="text-orange-700 bg-orange-50 p-3 rounded-lg">
                              ⚠ דורש תשומת לב נוספת
                            </p>
                            <p className="text-orange-700 bg-orange-50 p-3 rounded-lg">
                              ⚠ מומלץ מפגש הדרכה אישי
                            </p>
                          </>
                        )}
                      </div>
                    </div>

                    <button className="w-full mt-6 px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition">
                      צפייה בדו"ח מלא
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                    <Brain className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-xl mb-2">בחר סטודנט</h3>
                  <p className="text-gray-600">
                    לחץ על סטודנט כדי לראות את התקדמותו המפורטת
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
