import { useState } from 'react';
import { Paper } from '../App';
import { Upload, FileText, Sparkles } from 'lucide-react';

interface UploadPaperProps {
  onUpload: (paper: Paper) => void;
}

export function UploadPaper({ onUpload }: UploadPaperProps) {
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const simulateUpload = () => {
    setUploading(true);
    
    // Simulate processing delay
    setTimeout(() => {
      const newPaper: Paper = {
        id: Math.random().toString(36).substr(2, 9),
        title: 'Natural Language Processing in Healthcare: A Systematic Review',
        authors: ['Dr. Alex Johnson', 'Prof. Maria Garcia', 'Dr. James Wilson'],
        abstract: 'This systematic review examines the current state of Natural Language Processing (NLP) applications in healthcare settings. We analyzed 127 studies published between 2018-2023, focusing on clinical documentation, patient communication, and diagnostic support systems.',
        year: 2023,
        keywords: ['NLP', 'Healthcare', 'Clinical Documentation', 'AI in Medicine'],
        fullText: `
Introduction:
Natural Language Processing has emerged as a transformative technology in healthcare, enabling computers to understand and process human language in medical contexts.

Research Question:
What are the current applications, effectiveness, and limitations of NLP in healthcare settings?

Methodology:
We conducted a systematic review following PRISMA guidelines, searching PubMed, IEEE Xplore, and ACM Digital Library. Inclusion criteria required peer-reviewed studies with quantitative outcomes.

Results:
NLP applications showed high accuracy (average 89%) in clinical documentation tasks. Patient communication systems achieved 76% satisfaction rates. Diagnostic support systems demonstrated 85% accuracy but required human oversight.

Limitations:
Most studies were conducted in English-speaking countries, limiting generalizability. Long-term impact studies are lacking.

Conclusions:
NLP shows significant promise in healthcare but requires careful implementation with human oversight and continuous evaluation.
        `,
        uploadDate: new Date().toISOString().split('T')[0],
      };
      
      onUpload(newPaper);
      setUploading(false);
    }, 2000);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    simulateUpload();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      simulateUpload();
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl mb-2">העלאת מאמר חדש</h2>
        <p className="text-gray-600">
          העלו קובץ PDF של מאמר מדעי והמערכת תנתח אותו אוטומטית
        </p>
      </div>

      {/* Upload Area */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition ${
          dragActive
            ? 'border-indigo-600 bg-indigo-50'
            : 'border-gray-300 bg-white hover:border-indigo-400'
        }`}
      >
        <input
          type="file"
          id="file-upload"
          accept=".pdf"
          onChange={handleChange}
          className="sr-only"
        />
        
        {uploading ? (
          <div className="space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full">
              <Sparkles className="w-8 h-8 text-indigo-600 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl mb-2">מעבד את המאמר...</h3>
              <p className="text-gray-600">
                מחלץ טקסט, מזהה מחברים ומילות מפתח
              </p>
            </div>
            <div className="max-w-xs mx-auto bg-gray-200 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 h-full rounded-full animate-[pulse_1.5s_ease-in-out_infinite]" style={{ width: '70%' }} />
            </div>
          </div>
        ) : (
          <>
            <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mb-4">
              <Upload className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-xl mb-2">
              גררו קובץ PDF לכאן או לחצו להעלאה
            </h3>
            <p className="text-gray-600 mb-6">
              תומך בקבצי PDF עד 25MB
            </p>
            <label
              htmlFor="file-upload"
              className="inline-block px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 cursor-pointer transition"
            >
              בחירת קובץ
            </label>
          </>
        )}
      </div>

      {/* Features */}
      <div className="mt-8 grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <FileText className="w-8 h-8 text-indigo-600 mb-3" />
          <h3 className="mb-2">חילוץ אוטומטי</h3>
          <p className="text-gray-600">
            המערכת מחלצת אוטומטית את הכותרת, מחברים, תקציר ומילות מפתח
          </p>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <Sparkles className="w-8 h-8 text-purple-600 mb-3" />
          <h3 className="mb-2">ניתוח חכם</h3>
          <p className="text-gray-600">
            AI מנתח את מבנה המאמר ומזהה את החלקים המרכזיים
          </p>
        </div>
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <Upload className="w-8 h-8 text-pink-600 mb-3" />
          <h3 className="mb-2">תמיכה מלאה</h3>
          <p className="text-gray-600">
            תמיכה בכל פורמטי PDF האקדמיים הנפוצים
          </p>
        </div>
      </div>

      {/* Demo note */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p className="text-blue-900">
          <strong>הערה:</strong> זוהי גרסת דמו. בגרסה המלאה, המערכת תשתמש ב-OCR ו-NLP אמיתיים לחילוץ וניתוח תוכן המאמרים.
        </p>
      </div>
    </div>
  );
}
