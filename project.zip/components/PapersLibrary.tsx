import { Paper } from '../App';
import { Calendar, Users, Tag, BookOpen, Eye } from 'lucide-react';
import { useState } from 'react';
import { PaperReader } from './PaperReader';

interface PapersLibraryProps {
  papers: Paper[];
  onSelectPaper: (paper: Paper) => void;
}

export function PapersLibrary({ papers, onSelectPaper }: PapersLibraryProps) {
  const [readingPaper, setReadingPaper] = useState<Paper | null>(null);

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl mb-2">הספרייה שלי</h2>
        <p className="text-gray-600">
          {papers.length} מאמרים בספרייה
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {papers.map((paper) => (
          <div
            key={paper.id}
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded text-sm">
                {paper.year}
              </span>
            </div>

            <h3 className="mb-3 line-clamp-2">
              {paper.title}
            </h3>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-gray-600">
                <Users className="w-4 h-4" />
                <span className="text-sm truncate">
                  {paper.authors[0]}
                  {paper.authors.length > 1 && ` +${paper.authors.length - 1}`}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">
                  הועלה ב-{new Date(paper.uploadDate).toLocaleDateString('he-IL')}
                </span>
              </div>
            </div>

            <p className="text-gray-600 text-sm line-clamp-3 mb-4">
              {paper.abstract}
            </p>

            <div className="flex flex-wrap gap-2 mb-4">
              {paper.keywords.slice(0, 3).map((keyword, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
                >
                  <Tag className="w-3 h-3" />
                  {keyword}
                </span>
              ))}
              {paper.keywords.length > 3 && (
                <span className="px-2 py-1 text-gray-500 text-xs">
                  +{paper.keywords.length - 3}
                </span>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setReadingPaper(paper)}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-white border-2 border-indigo-600 text-indigo-600 rounded-lg hover:bg-indigo-50 transition"
              >
                <Eye className="w-4 h-4" />
                קרא מאמר
              </button>
              <button
                onClick={() => onSelectPaper(paper)}
                className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
              >
                שיחה
              </button>
            </div>
          </div>
        ))}
      </div>

      {readingPaper && (
        <PaperReader
          paper={readingPaper}
          onClose={() => setReadingPaper(null)}
        />
      )}
    </div>
  );
}