import { useState, useRef, useEffect } from 'react';
import { Paper, Message } from '../App';
import { Send, Bot, User, AlertCircle, Brain, BookOpen } from 'lucide-react';
import { mockChatHistories } from '../data/mockPapers';

interface ChatInterfaceProps {
  selectedPaper: Paper | null;
  socraticMode: boolean;
  onSelectPaper: () => void;
}

export function ChatInterface({ selectedPaper, socraticMode, onSelectPaper }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedPaper && mockChatHistories[selectedPaper.id]) {
      const history = mockChatHistories[selectedPaper.id];
      setMessages(
        history.map((msg, index) => ({
          id: `${selectedPaper.id}-${index}`,
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp,
        }))
      );
    } else {
      setMessages([]);
    }
  }, [selectedPaper]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const generateResponse = (userMessage: string): string => {
    if (!selectedPaper) return '';

    const lowerMessage = userMessage.toLowerCase();

    if (socraticMode) {
      // Socratic mode - respond with questions
      if (lowerMessage.includes('מטרת המחקר') || lowerMessage.includes('מטרה')) {
        return 'שאלה מצוינת! לפני שאענה, אשמח לשמוע - מה אתה חושב שהמטרה של המחקר הזה? נסה לזהות את זה מהתקציר או מההקדמה. איזה בעיה החוקרים מנסים לפתור?';
      }
      if (lowerMessage.includes('מתודולוגיה') || lowerMessage.includes('שיטה')) {
        return 'שאלה חשובה! במקום שאני אספר לך, נסה לחשוב - אם אתה היית צריך לחקור את הנושא הזה, איזו שיטת מחקר היית בוחר? ולמה דווקא אותה? אחר כך נשווה לשיטה שהחוקרים בחרו.';
      }
      if (lowerMessage.includes('תוצאות') || lowerMessage.includes('מה מצאו')) {
        return 'לפני שנדבר על התוצאות, בוא נעשה תרגיל חשיבה: לפי מה שקראת על המתודולוגיה והמטרה, אילו תוצאות היית מצפה למצוא? מה יהיה הגיוני?';
      }
      if (lowerMessage.includes('מגבלות') || lowerMessage.includes('חולשות')) {
        return 'שאלה ביקורתית מצוינת! אתה כבר מתחיל לחשוב כמו חוקר. בוא נחשוב ביחד - אם היית צריך לבקר את המחקר הזה, על מה היית מצביע? איזה דברים לא נחקרו או יכלו להיעשות אחרת?';
      }
      return 'זו שאלה מעניינת! במקום שאני אתן לך תשובה ישירה, בוא ננסה להגיע אליה ביחד. מה אתה כבר יודע על הנושא הזה מהמאמר? תצטט משפט אחד שנראה לך רלוונטי.';
    }

    // Regular mode - direct answers
    if (lowerMessage.includes('מטרת המחקר') || lowerMessage.includes('מטרה')) {
      if (selectedPaper.title.includes('Machine Learning')) {
        return 'מטרת המחקר היא לבחון האם מודלים של למידת מכונה יכולים להשיג ביצועים שווים או טובים יותר מאשר מומחים אנושיים בזיהוי גידולים ממאירים מסריקות CT במטרה לשפר את האבחון הרפואי המוקדם.';
      }
      if (selectedPaper.title.includes('Social Media')) {
        return 'מטרת המחקר היא להבין את הקשר בין דפוסי השימוש ברשתות חברתיות לבין הביצועים האקדמיים של סטודנטים באוניברסיטה.';
      }
      if (selectedPaper.title.includes('Climate')) {
        return 'מטרת המחקר היא לבחון כיצד שינויי האקלים השפיעו על המגוון הביולוגי באזור הים התיכון במהלך שני העשורים האחרונים, ולהעריך תחזיות עתידיות.';
      }
    }

    if (lowerMessage.includes('מתודולוגיה') || lowerMessage.includes('שיטה')) {
      if (selectedPaper.title.includes('Machine Learning')) {
        return 'החוקרים השתמשו ברשת נוירונים קונבולוציונית (CNN) המבוססת על ארכיטקטורת ResNet-50 עם התאמות מותאמות אישית לצילום רפואי. הם אימנו את המודל על מערך נתונים של 50,000 סריקות CT מתוייגות ממספר בתי חולים.';
      }
      if (selectedPaper.title.includes('Social Media')) {
        return 'החוקרים ביצעו מחקר אורכי (longitudinal study) במשך שנה אקדמית אחת עם 1,200 סטודנטים משלוש אוניברסיטאות. הסטודנטים דיווחו על השימוש שלהם ברשתות חברתיות דרך סקרים שבועיים, והחוקרים קיבלו את הרישומים האקדמיים שלהם בהסכמה.';
      }
      if (selectedPaper.title.includes('Climate')) {
        return 'החוקרים ביצעו סקרי שטח ב-150 אתרים ב-12 מדינות ים תיכוניות, והשוו את המגוון הביולוגי הנוכחי עם נתונים היסטוריים מהשנים 2000-2004. הם השתמשו במדדי עושר מינים ומדידות צפיפות אוכלוסייה.';
      }
    }

    if (lowerMessage.includes('תוצאות') || lowerMessage.includes('מה מצאו')) {
      if (selectedPaper.title.includes('Machine Learning')) {
        return 'המודל השיג דיוק של 94%, רגישות של 92% וספציפיות של 96%. זה מייצג שיפור של 7% לעומת שיטות האבחון המסורתיות. המודל הצליח לזהות גידולים ממאירים ברמת דיוק גבוהה יותר מהממוצע של מומחים אנושיים.';
      }
      if (selectedPaper.title.includes('Social Media')) {
        return 'החוקרים מצאו מתאם שלילי בינוני (-0.43, p<0.001) בין השימוש היומי ברשתות חברתיות לבין ממוצע הציונים. סטודנטים שהשתמשו ברשתות חברתיות יותר מ-3 שעות ביום היה להם ממוצע של 2.8, לעומת 3.4 לאלו שהשתמשו פחות משעה ביום. עם זאת, שימוש חינוכי ברשתות חברתיות הראה מתאם חיובי עם ממוצע הציונים.';
      }
      if (selectedPaper.title.includes('Climate')) {
        return 'הנתונים מראים ירידה של 23% באוכלוסיות המינים האנדמיים. מינים רגישים לטמפרטורה הראו את הירידות הדרמטיות ביותר (37%), בעוד שחלק מהמינים עמידים לחום אפילו גדלו באוכלוסייה. החוקרים מעריכים שתחת תרחישי הפליטה הנוכחיים, 30-40% נוספים מהמינים האנדמיים עלולים להתמודד עם הכחדה מקומית עד 2050.';
      }
    }

    if (lowerMessage.includes('מגבלות') || lowerMessage.includes('חולשות')) {
      if (selectedPaper.title.includes('Machine Learning')) {
        return 'המחקר הוגבל לסריקות CT ולא כלל הדמיה ב-MRI או צילומי רנטגן. בנוסף, מערך הנתונים היה בעיקר מבתי חולים עירוניים, מה שעלול להגביל את האפשרות להכליל את התוצאות לאזורים כפריים או לאוכלוסיות שונות.';
      }
      if (selectedPaper.title.includes('Social Media')) {
        return 'נתוני הדיווח העצמי עלולים להיות מוטים (הסטודנטים עלולים לא לדווח במדויק על זמן השימוש). בנוסף, המחקר לא שלט בכל המשתנים המתערבים האפשריים כמו מצב סוציו-אקונומי או ביצועים אקדמיים קודמים.';
      }
      if (selectedPaper.title.includes('Climate')) {
        return 'המחקר התמקד במערכות אקולוגיות יבשתיות ולא כיסה באופן מקיף את המגוון הביולוגי הימי. מגבלות תקציביות הגבילו את היכולת לבצע ניתוח גיוון גנטי.';
      }
    }

    if (lowerMessage.includes('מסקנות') || lowerMessage.includes('סיכום')) {
      if (selectedPaper.title.includes('Machine Learning')) {
        return 'למידת מכונה מראה פוטנציאל משמעותי באבחון רפואי, אך יש להשתמש בה ככלי משלים למומחיות אנושית ולא כתחליף. המחקר מציע שילוב של AI ומומחים אנושיים לתוצאות אבחון מיטביות.';
      }
      if (selectedPaper.title.includes('Social Media')) {
        return 'בעוד ששימוש מוגזם ברשתות חברתיות קשור לביצועים אקדמיים נמוכים יותר, שימוש מודע וחינוכי ברשתות חברתיות יכול להיות מועיל. המפתח הוא איכות השימוש ולא רק הכמות.';
      }
      if (selectedPaper.title.includes('Climate')) {
        return 'נדרשת פעולת שימור דחופה לשימור המגוון הביולוגי הים תיכוני. החוקרים ממליצים על הקמת אזורי שמורה נוספים ויישום תוכניות הגירה מסייעת למינים בסכנת הכחדה קריטית.';
      }
    }

    return `זו שאלה מעניינת על "${selectedPaper.title}". על בסיס הניתוח שלי של המאמר, אני רואה שהחוקרים מתמקדים ב${selectedPaper.keywords.slice(0, 2).join(' ו-')}. האם תרצה שאפרט על היבט ספציפי של המחקר?`;
  };

  const handleSend = () => {
    if (!input.trim() || !selectedPaper) return;

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate bot response delay
    setTimeout(() => {
      const botResponse: Message = {
        id: `msg-${Date.now()}-bot`,
        role: 'bot',
        content: generateResponse(input),
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  if (!selectedPaper) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
            <AlertCircle className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl mb-2">לא נבחר מאמר</h3>
          <p className="text-gray-600 mb-6">
            בחר מאמר מהספרייה כדי להתחיל שיחה עם הבוט
          </p>
          <button
            onClick={onSelectPaper}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
          >
            עבור לספרייה
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Paper Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4 flex-1">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">{selectedPaper.title}</h3>
              <p className="text-gray-600">
                {selectedPaper.authors.join(', ')} · {selectedPaper.year}
              </p>
            </div>
          </div>
          {socraticMode && (
            <div className="flex items-center gap-2 px-3 py-1 bg-purple-100 text-purple-700 rounded-full">
              <Brain className="w-4 h-4" />
              <span>מצב סוקרטי</span>
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col h-[600px]">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-full mb-4">
                <Bot className="w-8 h-8 text-indigo-600" />
              </div>
              <h3 className="text-xl mb-2">התחל שיחה</h3>
              <p className="text-gray-600 mb-6">
                {socraticMode
                  ? 'שאל שאלות על המאמר והבוט ידריך אותך בתהליך למידה עם שאלות מנחות'
                  : 'שאל שאלות על המאמר וקבל תשובות מפורטות'}
              </p>
              <div className="max-w-md mx-auto space-y-2 text-right">
                <p className="text-gray-700">דוגמאות לשאלות:</p>
                <ul className="space-y-1 text-gray-600">
                  <li>• מה מטרת המחקר?</li>
                  <li>• איזו מתודולוגיה השתמשו?</li>
                  <li>• מה התוצאות העיקריות?</li>
                  <li>• מה המגבלות של המחקר?</li>
                </ul>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'bot' && (
                <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-white" />
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <p className="whitespace-pre-wrap">{message.content}</p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-gray-600" />
                </div>
              )}
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-gray-100 rounded-2xl px-4 py-3">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="border-t border-gray-200 p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={socraticMode ? 'שאל שאלה והבוט ידריך אותך...' : 'שאל שאלה על המאמר...'}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
