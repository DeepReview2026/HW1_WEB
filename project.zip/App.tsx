import { useState } from 'react';
import { AuthScreen } from './components/AuthScreen';
import { StudentDashboard } from './components/StudentDashboard';
import { InstructorDashboard } from './components/InstructorDashboard';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'instructor';
}

export interface Paper {
  id: string;
  title: string;
  authors: string[];
  abstract: string;
  year: number;
  keywords: string[];
  fullText: string;
  uploadDate: string;
}

export interface Message {
  id: string;
  role: 'user' | 'bot';
  content: string;
  timestamp: string;
}

export interface ChatHistory {
  paperId: string;
  messages: Message[];
}

function App() {
  const [user, setUser] = useState<User | null>(null);

  const handleLogin = (userData: User) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (!user) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {user.role === 'student' ? (
        <StudentDashboard user={user} onLogout={handleLogout} />
      ) : (
        <InstructorDashboard user={user} onLogout={handleLogout} />
      )}
    </div>
  );
}

export default App;
