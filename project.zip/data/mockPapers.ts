import { Paper } from '../App';

export const mockPapers: Paper[] = [
  {
    id: '1',
    title: 'Machine Learning Applications in Medical Diagnosis',
    authors: ['Dr. Sarah Cohen', 'Prof. David Levy', 'Dr. Rachel Goldstein'],
    abstract: 'This study explores the application of machine learning algorithms in medical diagnosis, focusing on image recognition for early cancer detection. We demonstrate that deep learning models can achieve 94% accuracy in identifying malignant tumors from CT scans, outperforming traditional diagnostic methods.',
    year: 2023,
    keywords: ['Machine Learning', 'Medical Diagnosis', 'Deep Learning', 'Cancer Detection'],
    fullText: `
Introduction:
Medical diagnosis has traditionally relied on expert interpretation of medical imaging. However, the advent of machine learning has opened new possibilities for automated and more accurate diagnosis.

Research Question:
Can deep learning models match or exceed human expert performance in identifying malignant tumors from CT scans?

Methodology:
We trained a convolutional neural network (CNN) on a dataset of 50,000 labeled CT scans from multiple hospitals. The model architecture was based on ResNet-50 with custom modifications for medical imaging.

Results:
Our model achieved 94% accuracy, 92% sensitivity, and 96% specificity. This represents a 7% improvement over the baseline traditional diagnostic methods.

Limitations:
The study was limited to CT scans and did not include MRI or X-ray imaging. Additionally, the dataset was primarily from urban hospitals, which may limit generalizability.

Conclusions:
Machine learning shows significant promise in medical diagnosis, but should be used as a complementary tool to human expertise rather than a replacement.
    `,
    uploadDate: '2024-01-15',
  },
  {
    id: '2',
    title: 'The Impact of Social Media on Student Academic Performance',
    authors: ['Prof. Michael Brown', 'Dr. Jennifer White'],
    abstract: 'This research investigates the correlation between social media usage and academic performance among university students. Using a sample of 1,200 students, we found a moderate negative correlation (-0.43) between time spent on social media and GPA.',
    year: 2022,
    keywords: ['Social Media', 'Academic Performance', 'Education', 'Student Behavior'],
    fullText: `
Introduction:
Social media has become ubiquitous in students' daily lives. Understanding its impact on academic performance is crucial for educators and policymakers.

Research Question:
What is the relationship between social media usage patterns and academic performance in university students?

Methodology:
We conducted a longitudinal study over one academic year with 1,200 students from three universities. Students self-reported their social media usage through weekly surveys, and we obtained their academic records with consent.

Results:
We found a moderate negative correlation (-0.43, p<0.001) between daily social media usage and GPA. Students who used social media more than 3 hours daily had an average GPA of 2.8, compared to 3.4 for those using it less than 1 hour daily.

However, we also found that the type of social media usage matters. Educational content consumption showed a positive correlation with GPA.

Limitations:
Self-reported data may be subject to bias. We did not control for all potential confounding variables such as socioeconomic status or prior academic performance.

Conclusions:
While excessive social media use is associated with lower academic performance, mindful and educational use of social media can be beneficial.
    `,
    uploadDate: '2024-01-20',
  },
  {
    id: '3',
    title: 'Climate Change Effects on Mediterranean Biodiversity',
    authors: ['Dr. Elena Martinez', 'Prof. Giorgio Rossi', 'Dr. Yael Stein'],
    abstract: 'This comprehensive study examines the impact of rising temperatures on biodiversity in the Mediterranean region. Our findings indicate a 23% decline in endemic species over the past two decades, with projections suggesting further losses if current trends continue.',
    year: 2023,
    keywords: ['Climate Change', 'Biodiversity', 'Mediterranean', 'Ecology'],
    fullText: `
Introduction:
The Mediterranean basin is a biodiversity hotspot, home to thousands of endemic species. Climate change poses an existential threat to this unique ecosystem.

Research Question:
How has climate change affected biodiversity in the Mediterranean region over the past 20 years, and what are the future projections?

Methodology:
We conducted field surveys across 150 sites in 12 Mediterranean countries, comparing current biodiversity with historical data from 2000-2004. We used species richness indices and population density measurements.

Results:
Our data shows a 23% decline in endemic species populations. Temperature-sensitive species showed the most dramatic declines (37%), while some heat-tolerant species actually increased in population.

We project that under current emission scenarios, an additional 30-40% of endemic species may face local extinction by 2050.

Limitations:
Our study focused on terrestrial ecosystems and did not comprehensively cover marine biodiversity. Funding constraints limited our ability to conduct genetic diversity analysis.

Conclusions:
Urgent conservation action is needed to preserve Mediterranean biodiversity. We recommend establishing additional protected areas and implementing assisted migration programs for critically endangered species.
    `,
    uploadDate: '2024-02-01',
  },
];

export const mockChatHistories: Record<string, { role: 'user' | 'bot'; content: string; timestamp: string }[]> = {
  '1': [
    {
      role: 'user',
      content: 'מה שאלת המחקר המרכזית במאמר?',
      timestamp: '2024-01-15T10:30:00',
    },
    {
      role: 'bot',
      content: 'שאלת המחקר המרכזית היא: האם מודלים של למידת מכונה יכולים להשיג ביצועים שווים או טובים יותר מאשר מומחים אנושיים בזיהוי גידולים ממאירים מסריקות CT?',
      timestamp: '2024-01-15T10:30:15',
    },
    {
      role: 'user',
      content: 'איזו מתודולוגיה השתמשו במחקר?',
      timestamp: '2024-01-15T10:32:00',
    },
    {
      role: 'bot',
      content: 'החוקרים השתמשו ברשת נוירונים קונבולוציונית (CNN) המבוססת על ארכיטקטורת ResNet-50 עם התאמות מותאמות אישית לצילום רפואי. הם אימנו את המודל על מערך נתונים של 50,000 סריקות CT מתוייגות ממספר בתי חולים.',
      timestamp: '2024-01-15T10:32:12',
    },
  ],
};
